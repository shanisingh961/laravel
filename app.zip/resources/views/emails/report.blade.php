<h2>Hello {{ $patient->first_name }},</h2>
<p>Please find the attached report for your test.</p>
<br>
<p>Thanks,</p>
<h4>Healthy Heart</h4>