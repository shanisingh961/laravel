<h2>Hello {{ $user->first_name }},</h2>
<p>Your password for Healthy Heart Laboratory is: {{ $pass }}</p>