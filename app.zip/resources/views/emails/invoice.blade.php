<h2>Hello {{ $patient->first_name }},</h2>
<p>Please find the attached invoice for your appointment. Please make the payment to continue.</p>
<br>
<p>Thanks,</p>
<h4>Healthy Heart</h4>